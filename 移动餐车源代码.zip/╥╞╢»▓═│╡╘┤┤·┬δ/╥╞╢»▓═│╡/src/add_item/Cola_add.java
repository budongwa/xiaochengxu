package add_item;

public class Cola_add implements Item{
	public void add()
	{
		System.out.println("往贩卖机中添加可乐");
	}
}
