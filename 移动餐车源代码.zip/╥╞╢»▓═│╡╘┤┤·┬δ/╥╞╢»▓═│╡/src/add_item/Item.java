package add_item;

public interface Item {
	public void add();
}
