package add_item;

public interface Item_Factory {
	public Item produceDrink();
}
