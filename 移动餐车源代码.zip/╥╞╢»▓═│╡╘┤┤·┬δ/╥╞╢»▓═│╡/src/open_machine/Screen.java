package open_machine;

public class Screen
{
    public void TurnOff()
    {
        System.out.println("关闭显示屏");
    }
    public void TurnOn()
    {
        System.out.println("打开显示屏");
    }

}

