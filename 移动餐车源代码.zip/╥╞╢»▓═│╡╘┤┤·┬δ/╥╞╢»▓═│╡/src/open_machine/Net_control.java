package open_machine;

public class Net_control
{
    public void TurnOn()
    {
        System.out.println("连通网络");
    }
    public void TurnOff()
    {
        System.out.println("阻塞网络");
    }
}