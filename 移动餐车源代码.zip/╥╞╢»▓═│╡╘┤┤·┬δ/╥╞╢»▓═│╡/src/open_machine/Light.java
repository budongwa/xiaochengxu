package open_machine;

public class Light
{
    public void TurnOn()
    {
        System.out.println("打开灯光");
    }
    public void TurnOff()
    {
        System.out.println("关闭灯光");
    }

}