package add_meat;
public class Meal
{
	private String noodles;
	private String drink;
	private String meat;
	private int price;
	public String getMeat() {
		return meat;
	}
	public void setMeat(String meat) {
		this.meat = meat;
	}
	public String getDrink() {
		return drink;
	}
	public void setDrink(String drink) {
		this.drink = drink;
	}
	public String getNoodles() {
		return noodles;
	}
	public void setNoodles(String noodles) {
		this.noodles = noodles;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	


}