package add_meat;
public class Meat_A extends MealBuilder
{
	public void buildNoodles()
	{
		meal.setNoodles("��");
	}
	public void buildDrink()
	{
	    meal.setDrink("��");
	}
	public void buildMeat()
	{
		meal.setMeat("����*3");
	}
	public void buildPrice()
	{
		meal.setPrice(6);
	}
}