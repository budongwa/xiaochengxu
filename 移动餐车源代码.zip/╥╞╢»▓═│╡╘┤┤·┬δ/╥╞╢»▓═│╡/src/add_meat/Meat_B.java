package add_meat;
public class Meat_B extends MealBuilder
{
	public void buildNoodles()
	{
		meal.setNoodles("��̳���ţ����*1");
	}
	public void buildDrink()
	{
	    meal.setDrink("����*1");
	}
	public void buildMeat()
	{
		meal.setMeat("��");
	}
	public void buildPrice()
	{
		meal.setPrice(7);
	}
}