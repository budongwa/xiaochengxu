package com.bird.main;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.bird.util.Constant;

public class Cloud {
	//100ms���ٶ�
    private BufferedImage img;
    private int speed;
    
    //�Ƶ�����״̬
    public static final int DIR_NONE=0;
    public static final int DIR_LEFT=1;
    public static final int DIR_RIGHT=2;
    //����
    private int dir;
    private int x,y;
    
    //�Ƶ����ű���1-2��
    private double scale;
    private int scaleImageW,scaleImageH;
    
    public Cloud(BufferedImage img,int speed,int dir,int x) {
    	super();
    	this.img=img;
    	this.speed=Constant.CLOUD_SPEED;
    	this.dir=dir;
    	this.x=x;
    	this.y=y;
    	//��εõ�һ��1.0��2.0֮���doubleֵ
    	scale=1+Math.random();
    	//ȷ���ƶ�����ŵĿ��Ⱥ͸߶�
    	scaleImageW=(int)(scale*img.getWidth());
    	scaleImageH=(int)(scale*img.getHeight());
    }
    
    public void draw(Graphics g) {
    	int speed=this.speed;
    	if(dir==DIR_NONE)
    	speed=0;
    	
    	x=(dir==DIR_LEFT)?x-speed:x+speed;
    	g.drawImage(img, x, y, scaleImageW,scaleImageH,null);
    }
    
    //�ж��Ʋ������ɳ���Ļ
    //����ɳ�ȥ������true�����򷵻�false��
    public boolean isOutFrame() {
    	boolean result=false;
        if(dir == DIR_LEFT ) {
        	if(x<-img.getWidth(null)) {
        		return true;
        	}
     }
        else if(dir==DIR_RIGHT) {
        	if(x>Constant.FRAME_WIDTH) {
        		return true;
        	}
        }
        return result;
    }
    public void setDir(int dir) {
    	this.dir=dir;
    }
}
