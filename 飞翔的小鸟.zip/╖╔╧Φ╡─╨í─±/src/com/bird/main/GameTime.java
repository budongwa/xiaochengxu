package com.bird.main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import com.bird.util.Constant;

/*
 * ������Ϸ��ʱ����
 */
public class GameTime {
	//��Ϸ��״̬
	private static int timeState;
	//��û��ʼ��ʱ
	public static int STATE_READY=0;
	//��ʼ��ʱ
	public static final int STATE_RUN=1;
	//������ʱ
	public static final int STATE_OVER=2;
	
	//��Ϸ�ļ�ʱʱ�����
	private long startTime,endTime;
	//��ʷ�����
	private long bestTime;
	
	public GameTime() {
		timeState=STATE_READY;
		bestTime=-1;
		
		try {
			loadBestTime();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*
	 * װ����õļ�¼
	 */
	private void loadBestTime() throws Exception{
		File file =new File(Constant.SCORE_FILE_PATH);
		if(file.exists()) {
			DataInputStream dis=new DataInputStream(new FileInputStream(file));
			bestTime=dis.readLong();
			dis.close();
			}
	}
	
	/*
	 * �����¼
	 */
	public void saveBestTime(long time) throws Exception{
		File file =new File(Constant.SCORE_FILE_PATH);
		DataOutputStream dos=new DataOutputStream(new FileOutputStream(file));
		dos.writeLong(time);
		dos.close();
	}
	
	public long getBestTime() {
		return bestTime;
	}
	
	public int getTimeState() {
		return timeState;
	}
	
	public void setTimeState(int gameState) {
		this.timeState=gameState;
	}
	
	//�Ƿ�׼������
	public boolean isReady() {
		return timeState==STATE_READY;
	}
	
	/*
	 * �Ƿ����ڼ�ʱ
	 */
	public boolean isTiming() {
		return timeState==STATE_RUN;
	}
	
	public void setStartTime(long startTime) {
		this.startTime=startTime;
	}
	
	public void setEndTime(long endTime) {
		this.endTime=endTime;
	}
	
	//��ʼ��ʱ�ķ���
	public void startTiming() {
		startTime=System.currentTimeMillis();
		timeState=STATE_RUN;
		}
	
	//������ʱ�ķ���
	public void endTiming() {
		endTime=System.currentTimeMillis();
		timeState=STATE_OVER;
		
		long time=getSecondTime();
		if(bestTime<time) {
			bestTime=time;
			try {
				saveBestTime(endTime-startTime);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * ��Ϸ��ʱ�����ʱ��
	 */
	public long getTime() {
		if(STATE_RUN==timeState) {
			return System.currentTimeMillis()-startTime;
		}
		return endTime-startTime;
	}
	
	/*
	 * ��Ϸ��ʱ�����ʱ��
	 */
	public long getSecondTime() {
		return getTime()/1000;
	}

	public void reset() {
		timeState=STATE_READY;		
		startTime=0;
		endTime=0;
	}

}
