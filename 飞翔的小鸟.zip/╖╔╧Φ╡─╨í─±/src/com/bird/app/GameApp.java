package com.bird.app;
import com.bird.main.GameFrame;
public class GameApp {
      public static void main(String[] args) {
    	  new GameFrame();
      }
}
